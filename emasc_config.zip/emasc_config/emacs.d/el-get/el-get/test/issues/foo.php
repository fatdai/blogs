<?
# PHP test file for issue 400 and auto-mode-alist testing.
?>